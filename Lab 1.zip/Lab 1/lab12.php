<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratorio 1.2</title>
</head>

<body>
    <?php
    $n1 = 1;
    $n2 = 2;
    $suma = $n1 + $n2;
    echo "suma = " . $suma . "<br>";
    echo "$n1+$n2";
    ?>
</body>

</html>