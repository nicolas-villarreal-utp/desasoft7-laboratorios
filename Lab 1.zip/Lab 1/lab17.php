<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laboratorio 1.7</title>
</head>

<body>
    <?php

    $x = 24;
    $PI = 3.1416;
    $animal = "conejo";
    $saludo = "hola caracola";
    echo $x, "<br>", $PI,  "<br>", $animal,  "<br>", $saludo;
    ?>
</body>

</html>